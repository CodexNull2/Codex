RACEX PRO — 21 menu options
Install: extract the ZIP, run install.bat, open a NEW Command Prompt, type 1.

Options 1-9 are the original DNS, TCP, ping, traceroute, monitoring, system info,
limited common-port check, HTTP/HTTPS, and TLS diagnostics.

Options 10-21:
10 Internet reachability check (no public-IP lookup)
11 DNS timing test
12 Check a specific web path, e.g. /health
13 HTTP HEAD metadata check
14 TCP port presets
15 Save local-only report (no targets or test results)
16 DNS aliases and IPv4 results
17 Service greeting check
18 Local date/time details
19 Custom TCP timeout test
20 TLS ALPN / protocol negotiation
21 Python runtime details

No target history is saved. Use only on servers you own or have permission to test.
Port checks are limited diagnostics, not exhaustive scanning. Python 3 required.
