import os
import sys
import time
import socket
import platform
import subprocess
import shutil
import ssl
import urllib.request
import urllib.error
from datetime import datetime

RED = "\033[91m"
DARK_RED = "\033[31m"
WHITE = "\033[97m"
GRAY = "\033[90m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RESET = "\033[0m"
BOLD = "\033[1m"

COMMON_PORTS = [
    (21, "FTP"), (22, "SSH"), (25, "SMTP"), (53, "DNS/TCP"),
    (80, "HTTP"), (110, "POP3"), (143, "IMAP"), (443, "HTTPS"),
    (587, "SMTP submission"), (993, "IMAPS"), (995, "POP3S"),
    (25565, "Minecraft")
]


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def line():
    print(f"{DARK_RED}{'━' * 62}{RESET}")


def header():
    clear()
    print(f"""{RED}{BOLD}
    ██████╗  █████╗  ██████╗███████╗██╗  ██╗
    ██╔══██╗██╔══██╗██╔════╝██╔════╝╚██╗██╔╝
    ██████╔╝███████║██║     █████╗   ╚███╔╝
    ██╔══██╗██╔══██║██║     ██╔══╝   ██╔██╗
    ██║  ██║██║  ██║╚██████╗███████╗██╔╝ ██╗
    ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚══════╝╚═╝  ╚═╝
{RESET}{WHITE}           RACEX // PRO NETWORK TOOLKIT
{GRAY}       Diagnostics for systems you own or manage{RESET}
""")
    line()
    print(f"{GRAY}Local time: {datetime.now():%Y-%m-%d %H:%M:%S}  |  No target logs are saved{RESET}")
    line()


def ask_target():
    target = input(f"{RED}[?]{RESET} Server domain or IP: ").strip()
    if not target or len(target) > 253:
        print(f"{RED}[!] Invalid target.{RESET}")
        return None
    if any(c in target for c in ("/", "\\", " ", "@", ";", "&", "|", "\t")):
        print(f"{RED}[!] Enter a hostname or IP only, not a URL or command.{RESET}")
        return None
    try:
        socket.getaddrinfo(target, None)
        return target
    except socket.gaierror:
        print(f"{RED}[!] Hostname could not be resolved.{RESET}")
        return None


def resolve_addresses(target):
    results = socket.getaddrinfo(target, None)
    return sorted({item[4][0] for item in results})


def dns_lookup():
    target = ask_target()
    if not target:
        return
    try:
        print(f"\n{WHITE}DNS resolution: {target}{RESET}")
        for addr in resolve_addresses(target):
            print(f"  {GREEN}RESOLVED{RESET}  {addr}")
        print(f"{GRAY}Uses the system resolver; this is not a full DNS record audit.{RESET}")
    except socket.gaierror as exc:
        print(f"{RED}DNS failed: {exc}{RESET}")


def tcp_connect(target, port, timeout=2.0):
    started = time.perf_counter()
    with socket.create_connection((target, port), timeout=timeout):
        return (time.perf_counter() - started) * 1000


def custom_tcp_test():
    target = ask_target()
    if not target:
        return
    try:
        port = int(input("TCP port (1-65535): ").strip())
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        print(f"{RED}[!] Enter a port from 1 to 65535.{RESET}")
        return
    try:
        ms = tcp_connect(target, port, 3)
        print(f"\n{GREEN}[OPEN / REACHABLE]{RESET} {target}:{port} — {ms:.2f} ms")
    except OSError as exc:
        print(f"\n{RED}[NOT REACHABLE]{RESET} {target}:{port}")
        print(f"{GRAY}{exc}{RESET}")


def common_port_check():
    target = ask_target()
    if not target:
        return
    print(f"\n{WHITE}Checking a limited set of common TCP service ports on {target}{RESET}")
    print(f"{GRAY}Only run against systems you own or are authorized to test.{RESET}\n")
    found = []
    for port, service in COMMON_PORTS:
        try:
            ms = tcp_connect(target, port, 1.2)
            found.append((port, service, ms))
            print(f"{GREEN}[OPEN]{RESET}    {port:>5}  {service:<18} {ms:>7.1f} ms")
        except OSError:
            print(f"{GRAY}[NO CONNECT]{RESET} {port:>5}  {service}")
    line()
    print(f"{GREEN}{len(found)} of {len(COMMON_PORTS)} ports accepted a TCP connection.{RESET}")
    print(f"{GRAY}A failed connection may mean filtered, closed, or unreachable. This is not an exhaustive scan.{RESET}")


def ping_test():
    target = ask_target()
    if not target:
        return
    command = (["ping", "-n", "4", "-w", "2500", target]
               if platform.system() == "Windows"
               else ["ping", "-c", "4", "-W", "2", target])
    print(f"\n{WHITE}Ping test: {target} (4 packets){RESET}")
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=15)
        print((result.stdout or result.stderr or "No output.")[:6000])
        if result.returncode != 0:
            print(f"{YELLOW}Ping may be blocked even if the server is online.{RESET}")
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        print(f"{RED}Ping unavailable or timed out: {exc}{RESET}")


def traceroute():
    target = ask_target()
    if not target:
        return
    if platform.system() == "Windows":
        command = ["tracert", "-d", "-h", "15", "-w", "800", target]
    elif shutil.which("traceroute"):
        command = ["traceroute", "-m", "15", "-w", "1", target]
    else:
        print(f"{RED}Traceroute isn't installed. On Linux, install your distribution's traceroute package.{RESET}")
        return
    print(f"\n{WHITE}Route diagnostics: {target}{RESET}")
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=25)
        print((result.stdout or result.stderr or "No output.")[:9000])
    except subprocess.TimeoutExpired:
        print(f"{RED}Traceroute timed out.{RESET}")
    except OSError as exc:
        print(f"{RED}Could not run traceroute: {exc}{RESET}")


def server_monitor():
    target = ask_target()
    if not target:
        return
    try:
        port = int(input("TCP port to monitor: ").strip())
        duration = int(input("Duration in seconds (10-300): ").strip())
        if not 1 <= port <= 65535 or not 10 <= duration <= 300:
            raise ValueError
    except ValueError:
        print(f"{RED}[!] Port must be 1-65535 and duration 10-300 seconds.{RESET}")
        return

    print(f"\n{WHITE}Monitoring {target}:{port} every 2 seconds. Ctrl+C stops early.{RESET}\n")
    end = time.monotonic() + duration
    checks = good = 0
    times = []
    try:
        while time.monotonic() < end:
            checks += 1
            try:
                ms = tcp_connect(target, port, 2)
                good += 1
                times.append(ms)
                print(f"{GREEN}[ONLINE]{RESET} {datetime.now():%H:%M:%S} | {ms:.1f} ms")
            except OSError:
                print(f"{RED}[FAILED]{RESET} {datetime.now():%H:%M:%S} | no TCP connection")
            time.sleep(2)
    except KeyboardInterrupt:
        print("\nMonitor stopped by user.")
    line()
    print(f"Checks: {checks} | Successful: {good}")
    print(f"Availability during test: {good / checks * 100:.1f}%" if checks else "No checks completed.")
    if times:
        print(f"Min/avg/max connect time: {min(times):.1f} / {sum(times)/len(times):.1f} / {max(times):.1f} ms")


def http_check():
    target = ask_target()
    if not target:
        return
    scheme = input("Protocol [https/http] (default https): ").strip().lower() or "https"
    if scheme not in ("http", "https"):
        print(f"{RED}Choose http or https.{RESET}")
        return
    url = f"{scheme}://{target}/"
    request = urllib.request.Request(url, headers={"User-Agent": "RACEX-Diagnostics/1.0"})
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            elapsed = (time.perf_counter() - started) * 1000
            print(f"\n{GREEN}HTTP response received{RESET}")
            print(f"URL: {url}")
            print(f"Status: {response.status} {response.reason}")
            print(f"Response time: {elapsed:.1f} ms")
            print(f"Content-Type: {response.headers.get('Content-Type', 'unknown')}")
            print(f"Server header: {response.headers.get('Server', 'not disclosed')}")
    except urllib.error.HTTPError as exc:
        elapsed = (time.perf_counter() - started) * 1000
        print(f"{YELLOW}HTTP response: {exc.code} {exc.reason} ({elapsed:.1f} ms){RESET}")
        print("An HTTP error response still confirms that an HTTP service responded.")
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        print(f"{RED}HTTP check failed: {exc}{RESET}")


def tls_certificate():
    target = ask_target()
    if not target:
        return
    try:
        port = int(input("TLS port (default 443): ").strip() or "443")
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        print(f"{RED}Invalid port.{RESET}")
        return
    context = ssl.create_default_context()
    try:
        with socket.create_connection((target, port), timeout=4) as sock:
            with context.wrap_socket(sock, server_hostname=target) as secure:
                cert = secure.getpeercert()
                print(f"\n{GREEN}TLS handshake succeeded{RESET}")
                print(f"TLS version: {secure.version()}")
                print(f"Cipher: {secure.cipher()[0] if secure.cipher() else 'unknown'}")
                print(f"Certificate expires: {cert.get('notAfter', 'not provided')}")
                subject = dict(x[0] for x in cert.get("subject", ()))
                issuer = dict(x[0] for x in cert.get("issuer", ()))
                print(f"Subject: {subject.get('commonName', 'not provided')}")
                print(f"Issuer: {issuer.get('organizationName', issuer.get('commonName', 'not provided'))}")
    except (OSError, ssl.SSLError, ValueError) as exc:
        print(f"{RED}TLS check failed: {exc}{RESET}")


def system_info():
    print(f"\n{WHITE}LOCAL SYSTEM INFORMATION{RESET}")
    print(f"OS: {platform.system()} {platform.release()}")
    print(f"Python: {platform.python_version()}")
    print(f"Architecture: {platform.machine()}")
    print(f"Computer name: {socket.gethostname()}")
    print(f"Time: {datetime.now():%Y-%m-%d %H:%M:%S}")
    print(f"{GRAY}Target addresses are not saved to a file or displayed in a history log.{RESET}")




def internet_reachability():
    print("Checking a few public connectivity endpoints (no IP lookup or logging)...")
    checks = [("example.com", 443), ("www.cloudflare.com", 443), ("www.google.com", 443)]
    for host, port in checks:
        try:
            ms = tcp_connect(host, port, 3)
            print(f"{GREEN}[REACHABLE]{RESET} {host}:{port} — {ms:.1f} ms")
        except OSError:
            print(f"{YELLOW}[FAILED]{RESET} {host}:{port}")
    print("This tests outbound TCP connectivity, not your public IP address.")


def dns_timing():
    target = ask_target()
    if not target:
        return
    samples = []
    print(f"Timing system DNS resolution for {target}")
    for i in range(5):
        start = time.perf_counter()
        try:
            addresses = sorted({item[4][0] for item in socket.getaddrinfo(target, None)})
            ms = (time.perf_counter() - start) * 1000
            samples.append(ms)
            print(f"[{i+1}/5] {ms:.2f} ms — {', '.join(addresses[:6])}")
        except socket.gaierror as exc:
            print(f"[{i+1}/5] DNS failed: {exc}")
        time.sleep(0.3)
    if samples:
        print(f"Min/avg/max DNS time: {min(samples):.2f}/{sum(samples)/len(samples):.2f}/{max(samples):.2f} ms")


def check_url_path():
    target = ask_target()
    if not target:
        return
    path = input("Path to test (e.g. /health or /api/status): ").strip() or "/"
    if not path.startswith("/") or any(ch in path for ch in ("\r", "\n")):
        print("Enter a path beginning with /.")
        return
    scheme = input("Protocol [https/http] (default https): ").strip().lower() or "https"
    if scheme not in ("https", "http"):
        print("Choose https or http.")
        return
    url = f"{scheme}://{target}{path}"
    req = urllib.request.Request(url, headers={"User-Agent": "RACEX-Diagnostics/1.0"})
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=6) as response:
            ms = (time.perf_counter() - start) * 1000
            print(f"HTTP {response.status} {response.reason} — {ms:.1f} ms")
            print(f"Final URL: {response.geturl()}")
            print(f"Content-Type: {response.headers.get('Content-Type', 'unknown')}")
    except urllib.error.HTTPError as exc:
        ms = (time.perf_counter() - start) * 1000
        print(f"HTTP {exc.code} {exc.reason} — {ms:.1f} ms")
    except Exception as exc:
        print(f"Request failed: {exc}")


def check_http_method():
    target = ask_target()
    if not target:
        return
    scheme = input("Protocol [https/http] (default https): ").strip().lower() or "https"
    if scheme not in ("https", "http"):
        print("Choose https or http.")
        return
    url = f"{scheme}://{target}/"
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "RACEX-Diagnostics/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            print(f"HEAD request: HTTP {response.status} {response.reason}")
            print(f"Content-Type: {response.headers.get('Content-Type', 'unknown')}")
            print(f"Content-Length: {response.headers.get('Content-Length', 'not provided')}")
    except urllib.error.HTTPError as exc:
        print(f"HEAD returned HTTP {exc.code} {exc.reason}")
        print("Some servers do not support HEAD; this alone is not a fault.")
    except Exception as exc:
        print(f"Request failed: {exc}")


def tcp_port_presets():
    target = ask_target()
    if not target:
        return
    presets = {
        "1": [(80, "HTTP"), (443, "HTTPS")],
        "2": [(22, "SSH"), (80, "HTTP"), (443, "HTTPS")],
        "3": [(25565, "Minecraft"), (19132, "Minecraft Bedrock/UDP service port tested as TCP")],
        "4": [(3306, "MySQL"), (5432, "PostgreSQL"), (6379, "Redis"), (27017, "MongoDB")],
    }
    print("Preset: 1) Web  2) Web + SSH  3) Game service ports (TCP only)  4) Common database ports")
    choice = input("Choose preset (1-4): ").strip()
    if choice not in presets:
        print("Invalid preset.")
        return
    print("Checking only the selected preset's TCP ports:")
    for port, name in presets[choice]:
        try:
            ms = tcp_connect(target, port, 1.5)
            print(f"{GREEN}[OPEN]{RESET} {port:>5} {name:<30} {ms:.1f} ms")
        except OSError:
            print(f"{GRAY}[NO TCP CONNECTION]{RESET} {port:>5} {name}")
    print("UDP services are not tested by this feature.")


def save_report():
    print("This report contains only local environment and test metadata; it does not save target addresses.")
    filename = "racex_local_report.txt"
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write("RACEX LOCAL DIAGNOSTICS REPORT\n")
            f.write(f"Created: {datetime.now():%Y-%m-%d %H:%M:%S}\n")
            f.write(f"OS: {platform.system()} {platform.release()}\n")
            f.write(f"Python: {platform.python_version()}\n")
            f.write(f"Architecture: {platform.machine()}\n")
            f.write(f"Computer name: {socket.gethostname()}\n")
            f.write("No target addresses or scan results are included.\n")
        print(f"Saved {os.path.abspath(filename)}")
    except OSError as exc:
        print(f"Could not save report: {exc}")


def check_dns_aliases():
    target = ask_target()
    if not target:
        return
    try:
        canonical, aliases, addresses = socket.gethostbyname_ex(target)
        print(f"Canonical name: {canonical}")
        print(f"Aliases: {', '.join(aliases) if aliases else '(none returned)'}")
        print(f"IPv4 addresses: {', '.join(addresses) if addresses else '(none returned)'}")
        print("Uses the system resolver; it is not a full DNS record query.")
    except socket.gaierror as exc:
        print(f"DNS lookup failed: {exc}")


def check_server_banner():
    target = ask_target()
    if not target:
        return
    try:
        port = int(input("Port (common choices: 21, 22, 25, 80): ").strip())
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        print("Enter a port from 1 to 65535.")
        return
    try:
        with socket.create_connection((target, port), timeout=3) as sock:
            sock.settimeout(1.5)
            try:
                data = sock.recv(512)
                if data:
                    print("Service greeting (first 512 bytes):")
                    print(data.decode("utf-8", errors="replace").replace("\r", " ").replace("\n", " ")[:512])
                else:
                    print("Connected; service did not send an immediate greeting.")
            except socket.timeout:
                print("TCP connection succeeded; service sent no immediate greeting.")
    except OSError as exc:
        print(f"Connection failed: {exc}")


def check_date_time():
    print(f"Local date/time: {datetime.now().astimezone().isoformat(timespec='seconds')}")
    print(f"UTC date/time:   {datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')}")
    print(f"System timezone: {time.tzname}")


def check_tcp_timeout():
    target = ask_target()
    if not target:
        return
    try:
        port = int(input("TCP port: ").strip())
        timeout = float(input("Timeout in seconds (0.5-10, default 3): ").strip() or "3")
        if not 1 <= port <= 65535 or not 0.5 <= timeout <= 10:
            raise ValueError
    except ValueError:
        print("Port must be 1-65535 and timeout 0.5-10 seconds.")
        return
    start = time.perf_counter()
    try:
        with socket.create_connection((target, port), timeout=timeout):
            print(f"{GREEN}Connected in {(time.perf_counter()-start)*1000:.1f} ms{RESET}")
    except OSError as exc:
        elapsed = time.perf_counter() - start
        print(f"{YELLOW}No connection after {elapsed:.2f} s: {exc}{RESET}")


def check_tls_alpn():
    target = ask_target()
    if not target:
        return
    try:
        port = int(input("TLS port (default 443): ").strip() or "443")
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        print("Invalid port.")
        return
    try:
        context = ssl.create_default_context()
        context.set_alpn_protocols(["h2", "http/1.1"])
        with socket.create_connection((target, port), timeout=4) as sock:
            with context.wrap_socket(sock, server_hostname=target) as secure:
                print(f"TLS version: {secure.version()}")
                print(f"Negotiated application protocol: {secure.selected_alpn_protocol() or 'not negotiated'}")
                print(f"Cipher: {secure.cipher()[0] if secure.cipher() else 'unknown'}")
    except Exception as exc:
        print(f"TLS check failed: {exc}")


def local_python_modules():
    print("Python runtime:")
    print(f"Version: {platform.python_version()}")
    print(f"Executable: {sys.executable}")
    print("Built-in modules used by RACEX: socket, ssl, urllib, subprocess, platform, time, datetime")
    print("No third-party package installation is required.")

def menu():
    actions = {
        "1": ("DNS / hostname resolution", dns_lookup),
        "2": ("Custom TCP port test", custom_tcp_test),
        "3": ("Ping test (4 packets)", ping_test),
        "4": ("Traceroute", traceroute),
        "5": ("TCP server monitor", server_monitor),
        "6": ("Local system information", system_info),
        "7": ("Limited common TCP port check", common_port_check),
        "8": ("HTTP / HTTPS response check", http_check),
        "9": ("TLS certificate details", tls_certificate),
        "10": ("Internet connectivity check", internet_reachability),
        "11": ("DNS timing test", dns_timing),
        "12": ("Check a specific web path", check_url_path),
        "13": ("HTTP HEAD metadata check", check_http_method),
        "14": ("TCP port presets", tcp_port_presets),
        "15": ("Save local-only report", save_report),
        "16": ("DNS aliases and IPv4 results", check_dns_aliases),
        "17": ("Service greeting check", check_server_banner),
        "18": ("Local date/time details", check_date_time),
        "19": ("Custom TCP timeout test", check_tcp_timeout),
        "20": ("TLS ALPN / protocol negotiation", check_tls_alpn),
        "21": ("Python runtime details", local_python_modules),
    }
    while True:
        header()
        print(f"""
 {RED}[1]{WHITE} DNS / hostname resolution
 {RED}[2]{WHITE} Custom TCP port test
 {RED}[3]{WHITE} Ping test
 {RED}[4]{WHITE} Traceroute
 {RED}[5]{WHITE} TCP server monitor
 {RED}[6]{WHITE} Local system information
 {RED}[7]{WHITE} Limited common TCP port check
 {RED}[8]{WHITE} HTTP / HTTPS response check
 {RED}[9]{WHITE} TLS certificate details
 {RED}[10]{WHITE} Internet connectivity check
 {RED}[11]{WHITE} DNS timing test
 {RED}[12]{WHITE} Check a specific web path
 {RED}[13]{WHITE} HTTP HEAD metadata check
 {RED}[14]{WHITE} TCP port presets
 {RED}[15]{WHITE} Save local-only report
 {RED}[16]{WHITE} DNS aliases and IPv4 results
 {RED}[17]{WHITE} Service greeting check
 {RED}[18]{WHITE} Local date/time details
 {RED}[19]{WHITE} Custom TCP timeout test
 {RED}[20]{WHITE} TLS ALPN / protocol negotiation
 {RED}[21]{WHITE} Python runtime details
 {RED}[0]{WHITE} Exit
""")
        line()
        choice = input(f"{RED}RACEX PRO{WHITE} >> {RESET}").strip()
        if choice == "0":
            print(f"{RED}RACEX shutting down.{RESET}")
            break
        if choice in actions:
            clear()
            print(f"{RED}{BOLD}RACEX PRO // {actions[choice][0].upper()}{RESET}\n")
            actions[choice][1]()
            input(f"\n{GRAY}Press Enter to return to menu...{RESET}")
        else:
            print(f"{RED}Invalid selection.{RESET}")
            time.sleep(1)


if __name__ == "__main__":
    try:
        menu()
    except KeyboardInterrupt:
        print(f"\n{RED}RACEX terminated.{RESET}")
        sys.exit(0)
