@echo off
setlocal
title RACEX PRO Setup
color 0C
echo RACEX PRO - Installing updated version...
if not exist "%~dp0racex.py" (
  echo ERROR: racex.py is missing. Extract all ZIP files first.
  pause
  exit /b 1
)
if not exist "C:\RACEX" mkdir "C:\RACEX"
copy /Y "%~dp0racex.py" "C:\RACEX\racex.py" >nul
copy /Y "%~dp01.bat" "C:\RACEX\1.bat" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=[Environment]::GetEnvironmentVariable('Path','User'); if (($p -split ';') -notcontains 'C:\RACEX') { [Environment]::SetEnvironmentVariable('Path', (($p.TrimEnd(';') + ';C:\RACEX').Trim(';')), 'User') }"
echo.
echo RACEX PRO updated in C:\RACEX
echo Open a NEW Command Prompt and type: 1
echo.
pause
