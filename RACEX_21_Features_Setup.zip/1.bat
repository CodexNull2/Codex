@echo off
title RACEX PRO - Network Diagnostics
color 0C
cd /d "C:\RACEX"
py racex.py
if errorlevel 1 python racex.py
pause
